# gke-prometheus
Lab - Prometheus 
Please visit the following blog to setup prometheus in GKE (Kubernetes)
https://www.unixarena.com/2021/07/gke-install-and-configure-prometheus-kubernetes.html/
